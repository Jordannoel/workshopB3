<?php
/**
 * Created by PhpStorm.
 * User: Loïc Sicaire
 * Date: 30/08/2017
 * Time: 03:09
 */

namespace SnapAtSdk;


class Routes
{

    const URL_CONNEXION = "/connection";
    const URL_STATUS = "/status";
    const URL_REQUIREMENTS = "/requirements";
    const URL_CUSTOMERS = "/customers";

}