<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_7eb1ca209e4a6f678007f9191e858357989bf15e9a1f2f6dcfbd7477eac6d2e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8834959040b1ebc965367e2dde4888b5afb6c72178207282c9247a8aa7dceec1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8834959040b1ebc965367e2dde4888b5afb6c72178207282c9247a8aa7dceec1->enter($__internal_8834959040b1ebc965367e2dde4888b5afb6c72178207282c9247a8aa7dceec1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_a309c5b2b469ffc8d622ab10dd907a21256ac8a5a7933904ff8bd2df19449b3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a309c5b2b469ffc8d622ab10dd907a21256ac8a5a7933904ff8bd2df19449b3b->enter($__internal_a309c5b2b469ffc8d622ab10dd907a21256ac8a5a7933904ff8bd2df19449b3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_8834959040b1ebc965367e2dde4888b5afb6c72178207282c9247a8aa7dceec1->leave($__internal_8834959040b1ebc965367e2dde4888b5afb6c72178207282c9247a8aa7dceec1_prof);

        
        $__internal_a309c5b2b469ffc8d622ab10dd907a21256ac8a5a7933904ff8bd2df19449b3b->leave($__internal_a309c5b2b469ffc8d622ab10dd907a21256ac8a5a7933904ff8bd2df19449b3b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
