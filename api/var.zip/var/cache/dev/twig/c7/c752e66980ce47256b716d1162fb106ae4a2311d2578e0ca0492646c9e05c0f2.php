<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_333c399b3bd4125742ce8e295f028aca36bbf84eca188d41204b939f0b729192 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2252f1af1456db45d30b5c3b178834d5d3daae3a8d570aa30b8e44b612d2b6b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2252f1af1456db45d30b5c3b178834d5d3daae3a8d570aa30b8e44b612d2b6b4->enter($__internal_2252f1af1456db45d30b5c3b178834d5d3daae3a8d570aa30b8e44b612d2b6b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_c1ff8e91cd435dc52992de0d6bac1bd00dc7ea93815f3d66618783c5ab59be1d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1ff8e91cd435dc52992de0d6bac1bd00dc7ea93815f3d66618783c5ab59be1d->enter($__internal_c1ff8e91cd435dc52992de0d6bac1bd00dc7ea93815f3d66618783c5ab59be1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_2252f1af1456db45d30b5c3b178834d5d3daae3a8d570aa30b8e44b612d2b6b4->leave($__internal_2252f1af1456db45d30b5c3b178834d5d3daae3a8d570aa30b8e44b612d2b6b4_prof);

        
        $__internal_c1ff8e91cd435dc52992de0d6bac1bd00dc7ea93815f3d66618783c5ab59be1d->leave($__internal_c1ff8e91cd435dc52992de0d6bac1bd00dc7ea93815f3d66618783c5ab59be1d_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
