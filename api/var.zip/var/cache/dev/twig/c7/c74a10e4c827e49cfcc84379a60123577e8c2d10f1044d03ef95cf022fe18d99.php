<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_f21ab4e482dbc0556d765e1ce856c35da01a2cbec85481c9dfccf87c2c79808a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6bb27e7a72bf380b4efa3e00ce7b9219dcdafd3e348720379b099bb6ca7f530f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bb27e7a72bf380b4efa3e00ce7b9219dcdafd3e348720379b099bb6ca7f530f->enter($__internal_6bb27e7a72bf380b4efa3e00ce7b9219dcdafd3e348720379b099bb6ca7f530f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_a5944d55d50a8d90ca77cd69e000adcb8c29812cd80fbcbdfd072b5803a42b87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5944d55d50a8d90ca77cd69e000adcb8c29812cd80fbcbdfd072b5803a42b87->enter($__internal_a5944d55d50a8d90ca77cd69e000adcb8c29812cd80fbcbdfd072b5803a42b87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_6bb27e7a72bf380b4efa3e00ce7b9219dcdafd3e348720379b099bb6ca7f530f->leave($__internal_6bb27e7a72bf380b4efa3e00ce7b9219dcdafd3e348720379b099bb6ca7f530f_prof);

        
        $__internal_a5944d55d50a8d90ca77cd69e000adcb8c29812cd80fbcbdfd072b5803a42b87->leave($__internal_a5944d55d50a8d90ca77cd69e000adcb8c29812cd80fbcbdfd072b5803a42b87_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
