<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_e47a7f33666278a95e907e1a9dc0e908d70956eda8ea729d7f3e3eb654ac250f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca8c7732aea5a7e8372393fab35d16af82224067264b9c72194be7141657430a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca8c7732aea5a7e8372393fab35d16af82224067264b9c72194be7141657430a->enter($__internal_ca8c7732aea5a7e8372393fab35d16af82224067264b9c72194be7141657430a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_8e9862c5e52be0ea078bfbf123bb015a587af25393facd69a147837b9409c069 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e9862c5e52be0ea078bfbf123bb015a587af25393facd69a147837b9409c069->enter($__internal_8e9862c5e52be0ea078bfbf123bb015a587af25393facd69a147837b9409c069_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_ca8c7732aea5a7e8372393fab35d16af82224067264b9c72194be7141657430a->leave($__internal_ca8c7732aea5a7e8372393fab35d16af82224067264b9c72194be7141657430a_prof);

        
        $__internal_8e9862c5e52be0ea078bfbf123bb015a587af25393facd69a147837b9409c069->leave($__internal_8e9862c5e52be0ea078bfbf123bb015a587af25393facd69a147837b9409c069_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
