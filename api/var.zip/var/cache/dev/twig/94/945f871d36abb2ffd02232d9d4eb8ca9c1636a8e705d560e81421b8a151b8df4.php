<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_790f15cfabfde6a4515d4566c56690ab968508ab86c94d5f7b397677139081f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ba0461a8b3838518e9ae24b48c67dd1e5b61dd7c5ccfd52eecb04ecac2e48c07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba0461a8b3838518e9ae24b48c67dd1e5b61dd7c5ccfd52eecb04ecac2e48c07->enter($__internal_ba0461a8b3838518e9ae24b48c67dd1e5b61dd7c5ccfd52eecb04ecac2e48c07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_57fbe2b9c3b4c9419eb21e4efacd4aa2cb871cc49741dfc13981757da2e57e59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57fbe2b9c3b4c9419eb21e4efacd4aa2cb871cc49741dfc13981757da2e57e59->enter($__internal_57fbe2b9c3b4c9419eb21e4efacd4aa2cb871cc49741dfc13981757da2e57e59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo ($context["status_code"] ?? $this->getContext($context, "status_code"));
        echo " ";
        echo ($context["status_text"] ?? $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_ba0461a8b3838518e9ae24b48c67dd1e5b61dd7c5ccfd52eecb04ecac2e48c07->leave($__internal_ba0461a8b3838518e9ae24b48c67dd1e5b61dd7c5ccfd52eecb04ecac2e48c07_prof);

        
        $__internal_57fbe2b9c3b4c9419eb21e4efacd4aa2cb871cc49741dfc13981757da2e57e59->leave($__internal_57fbe2b9c3b4c9419eb21e4efacd4aa2cb871cc49741dfc13981757da2e57e59_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
