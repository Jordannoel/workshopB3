<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_9b39bd38d864ded649e3f6e25a41391e5e04cc702cce15f0bb32ee558430cd64 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c726f9f4593d05cd00d127a3bbbe05a7c838b75f0dcae522e4f2eca3710e092 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c726f9f4593d05cd00d127a3bbbe05a7c838b75f0dcae522e4f2eca3710e092->enter($__internal_3c726f9f4593d05cd00d127a3bbbe05a7c838b75f0dcae522e4f2eca3710e092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_a7857f232f52534b86d0858d2efe0d097a316dcd8f747bfb42f79fddb7a78af3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7857f232f52534b86d0858d2efe0d097a316dcd8f747bfb42f79fddb7a78af3->enter($__internal_a7857f232f52534b86d0858d2efe0d097a316dcd8f747bfb42f79fddb7a78af3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3c726f9f4593d05cd00d127a3bbbe05a7c838b75f0dcae522e4f2eca3710e092->leave($__internal_3c726f9f4593d05cd00d127a3bbbe05a7c838b75f0dcae522e4f2eca3710e092_prof);

        
        $__internal_a7857f232f52534b86d0858d2efe0d097a316dcd8f747bfb42f79fddb7a78af3->leave($__internal_a7857f232f52534b86d0858d2efe0d097a316dcd8f747bfb42f79fddb7a78af3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
