<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_1b42e1ddf6e8daf54f9259d32cd91c1db360d84456bec3fde5d27218bd2bc2ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58a15b672cbff75f735a6b29da6c08d36c78d3e792af5dae3fb97c8368c053a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58a15b672cbff75f735a6b29da6c08d36c78d3e792af5dae3fb97c8368c053a2->enter($__internal_58a15b672cbff75f735a6b29da6c08d36c78d3e792af5dae3fb97c8368c053a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_cdd6e6ea367e49201ebe3cb967d16fa4cdc11e39e5813ef27086e6f88964b2fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdd6e6ea367e49201ebe3cb967d16fa4cdc11e39e5813ef27086e6f88964b2fe->enter($__internal_cdd6e6ea367e49201ebe3cb967d16fa4cdc11e39e5813ef27086e6f88964b2fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_58a15b672cbff75f735a6b29da6c08d36c78d3e792af5dae3fb97c8368c053a2->leave($__internal_58a15b672cbff75f735a6b29da6c08d36c78d3e792af5dae3fb97c8368c053a2_prof);

        
        $__internal_cdd6e6ea367e49201ebe3cb967d16fa4cdc11e39e5813ef27086e6f88964b2fe->leave($__internal_cdd6e6ea367e49201ebe3cb967d16fa4cdc11e39e5813ef27086e6f88964b2fe_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
