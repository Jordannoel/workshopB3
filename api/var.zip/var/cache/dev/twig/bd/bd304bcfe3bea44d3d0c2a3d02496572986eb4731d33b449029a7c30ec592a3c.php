<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_0c39bf28106ec40a6cda8d0cfe2deb2242aa93632b434fa34c3b9fde99e68652 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6e4aeadb7b3cebc567e74bf1083ce9d17c846d66c1b54bda5d07b7d6c2544aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6e4aeadb7b3cebc567e74bf1083ce9d17c846d66c1b54bda5d07b7d6c2544aa->enter($__internal_d6e4aeadb7b3cebc567e74bf1083ce9d17c846d66c1b54bda5d07b7d6c2544aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_e8b013649c748a96557c2ae9e8e8d83ddb4d87fffe6f64ec0dce709f73def0ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e8b013649c748a96557c2ae9e8e8d83ddb4d87fffe6f64ec0dce709f73def0ad->enter($__internal_e8b013649c748a96557c2ae9e8e8d83ddb4d87fffe6f64ec0dce709f73def0ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_d6e4aeadb7b3cebc567e74bf1083ce9d17c846d66c1b54bda5d07b7d6c2544aa->leave($__internal_d6e4aeadb7b3cebc567e74bf1083ce9d17c846d66c1b54bda5d07b7d6c2544aa_prof);

        
        $__internal_e8b013649c748a96557c2ae9e8e8d83ddb4d87fffe6f64ec0dce709f73def0ad->leave($__internal_e8b013649c748a96557c2ae9e8e8d83ddb4d87fffe6f64ec0dce709f73def0ad_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
