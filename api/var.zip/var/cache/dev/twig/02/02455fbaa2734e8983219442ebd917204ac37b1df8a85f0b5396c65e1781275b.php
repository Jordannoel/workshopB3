<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_598e049b61823ad2836bb9f47a778eb83326f7bdfac6d9375e9b062c5845249a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_668b06ecf17c7cfb2b8d83a20d307b3fa269efffd42e3e4d51d2fe2969fae523 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_668b06ecf17c7cfb2b8d83a20d307b3fa269efffd42e3e4d51d2fe2969fae523->enter($__internal_668b06ecf17c7cfb2b8d83a20d307b3fa269efffd42e3e4d51d2fe2969fae523_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_e0be5fa1628ede05d8e838db9d6f0a4a5d5e71081ec195c09247505742c47135 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0be5fa1628ede05d8e838db9d6f0a4a5d5e71081ec195c09247505742c47135->enter($__internal_e0be5fa1628ede05d8e838db9d6f0a4a5d5e71081ec195c09247505742c47135_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_668b06ecf17c7cfb2b8d83a20d307b3fa269efffd42e3e4d51d2fe2969fae523->leave($__internal_668b06ecf17c7cfb2b8d83a20d307b3fa269efffd42e3e4d51d2fe2969fae523_prof);

        
        $__internal_e0be5fa1628ede05d8e838db9d6f0a4a5d5e71081ec195c09247505742c47135->leave($__internal_e0be5fa1628ede05d8e838db9d6f0a4a5d5e71081ec195c09247505742c47135_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
