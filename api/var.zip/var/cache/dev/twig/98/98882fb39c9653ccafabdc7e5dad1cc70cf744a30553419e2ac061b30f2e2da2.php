<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_fd92be7e6432c7a02abe94c7282a8557d41b1a96172d1d71ffa3d8ad9e6799a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_836f89e03e1690d5b0e9387f1a6f143b8ac37fec2b53f6d2003f61a528270744 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_836f89e03e1690d5b0e9387f1a6f143b8ac37fec2b53f6d2003f61a528270744->enter($__internal_836f89e03e1690d5b0e9387f1a6f143b8ac37fec2b53f6d2003f61a528270744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_b3fa9bca1e730687f3c46b4ca0076d0990d4c284fa160d371615dba7ea3997dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3fa9bca1e730687f3c46b4ca0076d0990d4c284fa160d371615dba7ea3997dc->enter($__internal_b3fa9bca1e730687f3c46b4ca0076d0990d4c284fa160d371615dba7ea3997dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_836f89e03e1690d5b0e9387f1a6f143b8ac37fec2b53f6d2003f61a528270744->leave($__internal_836f89e03e1690d5b0e9387f1a6f143b8ac37fec2b53f6d2003f61a528270744_prof);

        
        $__internal_b3fa9bca1e730687f3c46b4ca0076d0990d4c284fa160d371615dba7ea3997dc->leave($__internal_b3fa9bca1e730687f3c46b4ca0076d0990d4c284fa160d371615dba7ea3997dc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
