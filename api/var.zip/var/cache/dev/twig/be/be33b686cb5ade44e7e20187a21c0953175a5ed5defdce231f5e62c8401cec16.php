<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_c08bf877778582fdec794b9caa80fc0cc782285edc446736100a530820b35de1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9896d53b2507638764648e00383d406b9a78bdb025a0f08fa19c7d09d7b040b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9896d53b2507638764648e00383d406b9a78bdb025a0f08fa19c7d09d7b040b7->enter($__internal_9896d53b2507638764648e00383d406b9a78bdb025a0f08fa19c7d09d7b040b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_358ab9e1560f3895b72e58226aaa5743be539e8bc180eca69cf97dfd567d276c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_358ab9e1560f3895b72e58226aaa5743be539e8bc180eca69cf97dfd567d276c->enter($__internal_358ab9e1560f3895b72e58226aaa5743be539e8bc180eca69cf97dfd567d276c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_9896d53b2507638764648e00383d406b9a78bdb025a0f08fa19c7d09d7b040b7->leave($__internal_9896d53b2507638764648e00383d406b9a78bdb025a0f08fa19c7d09d7b040b7_prof);

        
        $__internal_358ab9e1560f3895b72e58226aaa5743be539e8bc180eca69cf97dfd567d276c->leave($__internal_358ab9e1560f3895b72e58226aaa5743be539e8bc180eca69cf97dfd567d276c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
