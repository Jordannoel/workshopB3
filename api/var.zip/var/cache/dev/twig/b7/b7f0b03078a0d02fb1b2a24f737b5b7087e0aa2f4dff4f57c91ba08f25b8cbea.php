<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_2f63b0f12ed9e9ed0461090b4ee7640c144842d17af306cd647ea6e6006f3f18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8b27ef085dc7d6a6dda6cd50cf7a9a249855475db2a6774aff835e63c5746ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8b27ef085dc7d6a6dda6cd50cf7a9a249855475db2a6774aff835e63c5746ff->enter($__internal_b8b27ef085dc7d6a6dda6cd50cf7a9a249855475db2a6774aff835e63c5746ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_0eadd50d9678305e2aa550f73dfc149caef64a98e87a74c54e82d8862bdc8c13 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eadd50d9678305e2aa550f73dfc149caef64a98e87a74c54e82d8862bdc8c13->enter($__internal_0eadd50d9678305e2aa550f73dfc149caef64a98e87a74c54e82d8862bdc8c13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_b8b27ef085dc7d6a6dda6cd50cf7a9a249855475db2a6774aff835e63c5746ff->leave($__internal_b8b27ef085dc7d6a6dda6cd50cf7a9a249855475db2a6774aff835e63c5746ff_prof);

        
        $__internal_0eadd50d9678305e2aa550f73dfc149caef64a98e87a74c54e82d8862bdc8c13->leave($__internal_0eadd50d9678305e2aa550f73dfc149caef64a98e87a74c54e82d8862bdc8c13_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
