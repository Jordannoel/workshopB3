<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_9ecddeb65954af326e08e59dc415095e3d5d2361d7468edc360abd7ffc046fb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31cc18ab94e8fee81242574c0d9196d60f67c996eee8dfe0df302b6f6fe683dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_31cc18ab94e8fee81242574c0d9196d60f67c996eee8dfe0df302b6f6fe683dd->enter($__internal_31cc18ab94e8fee81242574c0d9196d60f67c996eee8dfe0df302b6f6fe683dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_c730a1b35bfc2db5c0f6d7e058dbca2f83a7f8db7438e6340c01fadd6596ed06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c730a1b35bfc2db5c0f6d7e058dbca2f83a7f8db7438e6340c01fadd6596ed06->enter($__internal_c730a1b35bfc2db5c0f6d7e058dbca2f83a7f8db7438e6340c01fadd6596ed06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_31cc18ab94e8fee81242574c0d9196d60f67c996eee8dfe0df302b6f6fe683dd->leave($__internal_31cc18ab94e8fee81242574c0d9196d60f67c996eee8dfe0df302b6f6fe683dd_prof);

        
        $__internal_c730a1b35bfc2db5c0f6d7e058dbca2f83a7f8db7438e6340c01fadd6596ed06->leave($__internal_c730a1b35bfc2db5c0f6d7e058dbca2f83a7f8db7438e6340c01fadd6596ed06_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
