<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_eb26deccd428a4b2e5b7c1a86234bcb3dbcc79ac7da7fa4f478fbb4e66e94628 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b0d9b0c20710b0dc8c4a63648376afbdb99ec796f0d269919fbd7ca9fe5545f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7b0d9b0c20710b0dc8c4a63648376afbdb99ec796f0d269919fbd7ca9fe5545f->enter($__internal_7b0d9b0c20710b0dc8c4a63648376afbdb99ec796f0d269919fbd7ca9fe5545f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_0d73bf069ddb08ed2edb6bd18a50d566f00ceedd882a19e7b2747ded3e5eaa43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d73bf069ddb08ed2edb6bd18a50d566f00ceedd882a19e7b2747ded3e5eaa43->enter($__internal_0d73bf069ddb08ed2edb6bd18a50d566f00ceedd882a19e7b2747ded3e5eaa43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_7b0d9b0c20710b0dc8c4a63648376afbdb99ec796f0d269919fbd7ca9fe5545f->leave($__internal_7b0d9b0c20710b0dc8c4a63648376afbdb99ec796f0d269919fbd7ca9fe5545f_prof);

        
        $__internal_0d73bf069ddb08ed2edb6bd18a50d566f00ceedd882a19e7b2747ded3e5eaa43->leave($__internal_0d73bf069ddb08ed2edb6bd18a50d566f00ceedd882a19e7b2747ded3e5eaa43_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
