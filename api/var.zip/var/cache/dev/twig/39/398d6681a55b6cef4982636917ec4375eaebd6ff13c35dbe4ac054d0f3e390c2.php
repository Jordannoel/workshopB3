<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_71c2e4e735264b42666f2c123bb1ee121d1d6f96b9a1c3d6cacb56c0d5ea7820 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25e42133c2b343747161909dae4a72069852ed2e7a704c54724984a4de28a93b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25e42133c2b343747161909dae4a72069852ed2e7a704c54724984a4de28a93b->enter($__internal_25e42133c2b343747161909dae4a72069852ed2e7a704c54724984a4de28a93b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_bed3967d5a6f4e0504a93390d364b321f59bb285943d5ab9054bd11be88f8c52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bed3967d5a6f4e0504a93390d364b321f59bb285943d5ab9054bd11be88f8c52->enter($__internal_bed3967d5a6f4e0504a93390d364b321f59bb285943d5ab9054bd11be88f8c52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_25e42133c2b343747161909dae4a72069852ed2e7a704c54724984a4de28a93b->leave($__internal_25e42133c2b343747161909dae4a72069852ed2e7a704c54724984a4de28a93b_prof);

        
        $__internal_bed3967d5a6f4e0504a93390d364b321f59bb285943d5ab9054bd11be88f8c52->leave($__internal_bed3967d5a6f4e0504a93390d364b321f59bb285943d5ab9054bd11be88f8c52_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
