<?php

/* @App/Commercials/connect.html.twig */
class __TwigTemplate_89a45a93cda7dc12d3ec6b696cfbf5464130de45dd6749ecd9e2f2ccac6ec61d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "@App/Commercials/connect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dfba017e58cbcc351f61ac35bdb0bc3a7bc29249033b56ba51cb93d0885e07b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dfba017e58cbcc351f61ac35bdb0bc3a7bc29249033b56ba51cb93d0885e07b4->enter($__internal_dfba017e58cbcc351f61ac35bdb0bc3a7bc29249033b56ba51cb93d0885e07b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/Commercials/connect.html.twig"));

        $__internal_a5a73b7682705c4befd7295e74b32a9f4a7198b91f2163039ac0b9e3015f5f2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5a73b7682705c4befd7295e74b32a9f4a7198b91f2163039ac0b9e3015f5f2a->enter($__internal_a5a73b7682705c4befd7295e74b32a9f4a7198b91f2163039ac0b9e3015f5f2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/Commercials/connect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dfba017e58cbcc351f61ac35bdb0bc3a7bc29249033b56ba51cb93d0885e07b4->leave($__internal_dfba017e58cbcc351f61ac35bdb0bc3a7bc29249033b56ba51cb93d0885e07b4_prof);

        
        $__internal_a5a73b7682705c4befd7295e74b32a9f4a7198b91f2163039ac0b9e3015f5f2a->leave($__internal_a5a73b7682705c4befd7295e74b32a9f4a7198b91f2163039ac0b9e3015f5f2a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7a84ada4d9e6d44e515616daf26154eeaa39e4b6f88b196e6dbf840db7c59393 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a84ada4d9e6d44e515616daf26154eeaa39e4b6f88b196e6dbf840db7c59393->enter($__internal_7a84ada4d9e6d44e515616daf26154eeaa39e4b6f88b196e6dbf840db7c59393_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0af9f1f78428eb5bb4dcab4e86d0da647ebb09f5eb240aaaae3d7d9fd3f589fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0af9f1f78428eb5bb4dcab4e86d0da647ebb09f5eb240aaaae3d7d9fd3f589fe->enter($__internal_0af9f1f78428eb5bb4dcab4e86d0da647ebb09f5eb240aaaae3d7d9fd3f589fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:Commercials:connect";
        
        $__internal_0af9f1f78428eb5bb4dcab4e86d0da647ebb09f5eb240aaaae3d7d9fd3f589fe->leave($__internal_0af9f1f78428eb5bb4dcab4e86d0da647ebb09f5eb240aaaae3d7d9fd3f589fe_prof);

        
        $__internal_7a84ada4d9e6d44e515616daf26154eeaa39e4b6f88b196e6dbf840db7c59393->leave($__internal_7a84ada4d9e6d44e515616daf26154eeaa39e4b6f88b196e6dbf840db7c59393_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_cabd88aa8368ec9c7d7efc12b5d8c85b7038da3c15a0f6f83829e565abe2e966 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cabd88aa8368ec9c7d7efc12b5d8c85b7038da3c15a0f6f83829e565abe2e966->enter($__internal_cabd88aa8368ec9c7d7efc12b5d8c85b7038da3c15a0f6f83829e565abe2e966_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_206a31b562c2f847359b67b39cc3f56e3946c3362c6f85b0d39f7cd8d3b5713c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_206a31b562c2f847359b67b39cc3f56e3946c3362c6f85b0d39f7cd8d3b5713c->enter($__internal_206a31b562c2f847359b67b39cc3f56e3946c3362c6f85b0d39f7cd8d3b5713c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Commercials:connect page</h1>
";
        
        $__internal_206a31b562c2f847359b67b39cc3f56e3946c3362c6f85b0d39f7cd8d3b5713c->leave($__internal_206a31b562c2f847359b67b39cc3f56e3946c3362c6f85b0d39f7cd8d3b5713c_prof);

        
        $__internal_cabd88aa8368ec9c7d7efc12b5d8c85b7038da3c15a0f6f83829e565abe2e966->leave($__internal_cabd88aa8368ec9c7d7efc12b5d8c85b7038da3c15a0f6f83829e565abe2e966_prof);

    }

    public function getTemplateName()
    {
        return "@App/Commercials/connect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block title %}AppBundle:Commercials:connect{% endblock %}

{% block body %}
<h1>Welcome to the Commercials:connect page</h1>
{% endblock %}
", "@App/Commercials/connect.html.twig", "C:\\wamp\\www\\workshopB3\\api\\src\\AppBundle\\Resources\\views\\Commercials\\connect.html.twig");
    }
}
