<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_deac31068765dec5e034951f27f806fc352d4f63595b077cefca755a218ead4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3182f9ef79885fa49d241dad4d996f4f484c5260f7e14f3d6020ef4ce88132f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3182f9ef79885fa49d241dad4d996f4f484c5260f7e14f3d6020ef4ce88132f4->enter($__internal_3182f9ef79885fa49d241dad4d996f4f484c5260f7e14f3d6020ef4ce88132f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_ee6b3847d1a999f97e7b99c6d01747656c4bbb35f270ed06b2ae20bbda2decf6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee6b3847d1a999f97e7b99c6d01747656c4bbb35f270ed06b2ae20bbda2decf6->enter($__internal_ee6b3847d1a999f97e7b99c6d01747656c4bbb35f270ed06b2ae20bbda2decf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_3182f9ef79885fa49d241dad4d996f4f484c5260f7e14f3d6020ef4ce88132f4->leave($__internal_3182f9ef79885fa49d241dad4d996f4f484c5260f7e14f3d6020ef4ce88132f4_prof);

        
        $__internal_ee6b3847d1a999f97e7b99c6d01747656c4bbb35f270ed06b2ae20bbda2decf6->leave($__internal_ee6b3847d1a999f97e7b99c6d01747656c4bbb35f270ed06b2ae20bbda2decf6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
