<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_bf8ed3c6a725e6de382e0ac4e9cf0050be09b5da19eb771f08b5505dcd0fb67f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92805145d01843da6789c28b575de4b07f52403177646e86b391ed661dccfc0e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92805145d01843da6789c28b575de4b07f52403177646e86b391ed661dccfc0e->enter($__internal_92805145d01843da6789c28b575de4b07f52403177646e86b391ed661dccfc0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_5ef1380bf17c23ea6dffad9a44d168c486dd963ddb3613bbf5dca8cf8139f6e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ef1380bf17c23ea6dffad9a44d168c486dd963ddb3613bbf5dca8cf8139f6e6->enter($__internal_5ef1380bf17c23ea6dffad9a44d168c486dd963ddb3613bbf5dca8cf8139f6e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_92805145d01843da6789c28b575de4b07f52403177646e86b391ed661dccfc0e->leave($__internal_92805145d01843da6789c28b575de4b07f52403177646e86b391ed661dccfc0e_prof);

        
        $__internal_5ef1380bf17c23ea6dffad9a44d168c486dd963ddb3613bbf5dca8cf8139f6e6->leave($__internal_5ef1380bf17c23ea6dffad9a44d168c486dd963ddb3613bbf5dca8cf8139f6e6_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f12575960652109842d535bfa5d958aa45c05c52550f4d97c9d943191d64466b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f12575960652109842d535bfa5d958aa45c05c52550f4d97c9d943191d64466b->enter($__internal_f12575960652109842d535bfa5d958aa45c05c52550f4d97c9d943191d64466b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_8538179ece0ea0c23e17416c4a432c5091e6576141e888196b1c3b363136c852 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8538179ece0ea0c23e17416c4a432c5091e6576141e888196b1c3b363136c852->enter($__internal_8538179ece0ea0c23e17416c4a432c5091e6576141e888196b1c3b363136c852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_8538179ece0ea0c23e17416c4a432c5091e6576141e888196b1c3b363136c852->leave($__internal_8538179ece0ea0c23e17416c4a432c5091e6576141e888196b1c3b363136c852_prof);

        
        $__internal_f12575960652109842d535bfa5d958aa45c05c52550f4d97c9d943191d64466b->leave($__internal_f12575960652109842d535bfa5d958aa45c05c52550f4d97c9d943191d64466b_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_93768bb2cc96ce5abba563973b413e704712bdfebe05e72e5979ab394d2630ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93768bb2cc96ce5abba563973b413e704712bdfebe05e72e5979ab394d2630ea->enter($__internal_93768bb2cc96ce5abba563973b413e704712bdfebe05e72e5979ab394d2630ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f76ad39a596fedf3bc74a1d51942dc4730ff819440418e7aa247f6d28cdcbf06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f76ad39a596fedf3bc74a1d51942dc4730ff819440418e7aa247f6d28cdcbf06->enter($__internal_f76ad39a596fedf3bc74a1d51942dc4730ff819440418e7aa247f6d28cdcbf06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_f76ad39a596fedf3bc74a1d51942dc4730ff819440418e7aa247f6d28cdcbf06->leave($__internal_f76ad39a596fedf3bc74a1d51942dc4730ff819440418e7aa247f6d28cdcbf06_prof);

        
        $__internal_93768bb2cc96ce5abba563973b413e704712bdfebe05e72e5979ab394d2630ea->leave($__internal_93768bb2cc96ce5abba563973b413e704712bdfebe05e72e5979ab394d2630ea_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
