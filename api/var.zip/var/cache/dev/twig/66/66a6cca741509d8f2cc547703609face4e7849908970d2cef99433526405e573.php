<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_987ac1695af07336547e168128399df4bd6c257ab9e89891fcee1bad7d943e81 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2cc36d64a742e82094ecfe15461ef0c259a5df7ddf3a4f0a6e32df168e81dcf6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2cc36d64a742e82094ecfe15461ef0c259a5df7ddf3a4f0a6e32df168e81dcf6->enter($__internal_2cc36d64a742e82094ecfe15461ef0c259a5df7ddf3a4f0a6e32df168e81dcf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_bef6bff7d0eb9690e2b5fdd8b816066c85d6b411252f8aed3a47e1647d638b34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bef6bff7d0eb9690e2b5fdd8b816066c85d6b411252f8aed3a47e1647d638b34->enter($__internal_bef6bff7d0eb9690e2b5fdd8b816066c85d6b411252f8aed3a47e1647d638b34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_2cc36d64a742e82094ecfe15461ef0c259a5df7ddf3a4f0a6e32df168e81dcf6->leave($__internal_2cc36d64a742e82094ecfe15461ef0c259a5df7ddf3a4f0a6e32df168e81dcf6_prof);

        
        $__internal_bef6bff7d0eb9690e2b5fdd8b816066c85d6b411252f8aed3a47e1647d638b34->leave($__internal_bef6bff7d0eb9690e2b5fdd8b816066c85d6b411252f8aed3a47e1647d638b34_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
