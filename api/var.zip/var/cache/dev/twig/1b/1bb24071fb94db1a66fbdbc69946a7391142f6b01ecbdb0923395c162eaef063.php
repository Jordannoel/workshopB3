<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_76cb0bd9680c7883661e1355acb7c7e173271c238c6f09cbf1f743f1d384ea40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ca62a423ebbbd84a7d05c1fcfca78d9bdf3c6df93d1b51b543f134b6e51a44e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ca62a423ebbbd84a7d05c1fcfca78d9bdf3c6df93d1b51b543f134b6e51a44e->enter($__internal_9ca62a423ebbbd84a7d05c1fcfca78d9bdf3c6df93d1b51b543f134b6e51a44e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_ead794d7e13dff42a1fb8fc724e51ae7e7c00234eb0da6992dc5501cc85f816b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ead794d7e13dff42a1fb8fc724e51ae7e7c00234eb0da6992dc5501cc85f816b->enter($__internal_ead794d7e13dff42a1fb8fc724e51ae7e7c00234eb0da6992dc5501cc85f816b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
*/
";
        
        $__internal_9ca62a423ebbbd84a7d05c1fcfca78d9bdf3c6df93d1b51b543f134b6e51a44e->leave($__internal_9ca62a423ebbbd84a7d05c1fcfca78d9bdf3c6df93d1b51b543f134b6e51a44e_prof);

        
        $__internal_ead794d7e13dff42a1fb8fc724e51ae7e7c00234eb0da6992dc5501cc85f816b->leave($__internal_ead794d7e13dff42a1fb8fc724e51ae7e7c00234eb0da6992dc5501cc85f816b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
