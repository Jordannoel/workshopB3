<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_9d475fb8f7d7590877abafd14afacceec090b441375fed86176457c377d87a5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_843eac70083c4a63c886609e81a7025519d1ae19d831516f31cdfd455e98682a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_843eac70083c4a63c886609e81a7025519d1ae19d831516f31cdfd455e98682a->enter($__internal_843eac70083c4a63c886609e81a7025519d1ae19d831516f31cdfd455e98682a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_89063f60990b9ef590f2dac7fbc3d60a29bff449a570ce758f6ef6ce472357cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89063f60990b9ef590f2dac7fbc3d60a29bff449a570ce758f6ef6ce472357cb->enter($__internal_89063f60990b9ef590f2dac7fbc3d60a29bff449a570ce758f6ef6ce472357cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_843eac70083c4a63c886609e81a7025519d1ae19d831516f31cdfd455e98682a->leave($__internal_843eac70083c4a63c886609e81a7025519d1ae19d831516f31cdfd455e98682a_prof);

        
        $__internal_89063f60990b9ef590f2dac7fbc3d60a29bff449a570ce758f6ef6ce472357cb->leave($__internal_89063f60990b9ef590f2dac7fbc3d60a29bff449a570ce758f6ef6ce472357cb_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_48af0340b5731ecc0445a74d6615f90ba469bfb4ac1f1821c88c6c0bac305831 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_48af0340b5731ecc0445a74d6615f90ba469bfb4ac1f1821c88c6c0bac305831->enter($__internal_48af0340b5731ecc0445a74d6615f90ba469bfb4ac1f1821c88c6c0bac305831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5bc9bcbd887dc827a1b8b7c0428492233719a11663b5bbd4111ec89b4cd6aa65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5bc9bcbd887dc827a1b8b7c0428492233719a11663b5bbd4111ec89b4cd6aa65->enter($__internal_5bc9bcbd887dc827a1b8b7c0428492233719a11663b5bbd4111ec89b4cd6aa65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_5bc9bcbd887dc827a1b8b7c0428492233719a11663b5bbd4111ec89b4cd6aa65->leave($__internal_5bc9bcbd887dc827a1b8b7c0428492233719a11663b5bbd4111ec89b4cd6aa65_prof);

        
        $__internal_48af0340b5731ecc0445a74d6615f90ba469bfb4ac1f1821c88c6c0bac305831->leave($__internal_48af0340b5731ecc0445a74d6615f90ba469bfb4ac1f1821c88c6c0bac305831_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_66a91f150da551722790d133ea5f8459e90b0073573f99d67518c6258c6682af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66a91f150da551722790d133ea5f8459e90b0073573f99d67518c6258c6682af->enter($__internal_66a91f150da551722790d133ea5f8459e90b0073573f99d67518c6258c6682af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3af7c5945c3b14790b6fe18d4999d3c08cd6eca388e79c307cedea5c96b8306c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3af7c5945c3b14790b6fe18d4999d3c08cd6eca388e79c307cedea5c96b8306c->enter($__internal_3af7c5945c3b14790b6fe18d4999d3c08cd6eca388e79c307cedea5c96b8306c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, ($context["location"] ?? $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_3af7c5945c3b14790b6fe18d4999d3c08cd6eca388e79c307cedea5c96b8306c->leave($__internal_3af7c5945c3b14790b6fe18d4999d3c08cd6eca388e79c307cedea5c96b8306c_prof);

        
        $__internal_66a91f150da551722790d133ea5f8459e90b0073573f99d67518c6258c6682af->leave($__internal_66a91f150da551722790d133ea5f8459e90b0073573f99d67518c6258c6682af_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
