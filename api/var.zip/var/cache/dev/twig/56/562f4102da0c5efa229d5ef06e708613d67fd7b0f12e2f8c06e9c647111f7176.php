<?php

/* AppBundle:Commercials:connect.html.twig */
class __TwigTemplate_d8d47b45ed7b4230f0d293924e35f2ea40d7534ab4f788ee761c0b521db3ac23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:Commercials:connect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1d6b57e80a291fb24df8c08f5dfe0920ddd33e4d6d1f011ed0c4a032f150554 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1d6b57e80a291fb24df8c08f5dfe0920ddd33e4d6d1f011ed0c4a032f150554->enter($__internal_d1d6b57e80a291fb24df8c08f5dfe0920ddd33e4d6d1f011ed0c4a032f150554_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Commercials:connect.html.twig"));

        $__internal_265af52c082cf3746ca7aa552776ba157089fc788f75cd08ce424bfb892b786e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_265af52c082cf3746ca7aa552776ba157089fc788f75cd08ce424bfb892b786e->enter($__internal_265af52c082cf3746ca7aa552776ba157089fc788f75cd08ce424bfb892b786e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Commercials:connect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d1d6b57e80a291fb24df8c08f5dfe0920ddd33e4d6d1f011ed0c4a032f150554->leave($__internal_d1d6b57e80a291fb24df8c08f5dfe0920ddd33e4d6d1f011ed0c4a032f150554_prof);

        
        $__internal_265af52c082cf3746ca7aa552776ba157089fc788f75cd08ce424bfb892b786e->leave($__internal_265af52c082cf3746ca7aa552776ba157089fc788f75cd08ce424bfb892b786e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_59b6c4de4558e5ef7e9e2d690765715f114127cb05bf99bd50e176857940f873 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59b6c4de4558e5ef7e9e2d690765715f114127cb05bf99bd50e176857940f873->enter($__internal_59b6c4de4558e5ef7e9e2d690765715f114127cb05bf99bd50e176857940f873_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b3bf2f68717cfd95bad8c7406824f2184043708698b5d80e7173004d9719f80f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3bf2f68717cfd95bad8c7406824f2184043708698b5d80e7173004d9719f80f->enter($__internal_b3bf2f68717cfd95bad8c7406824f2184043708698b5d80e7173004d9719f80f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:Commercials:connect";
        
        $__internal_b3bf2f68717cfd95bad8c7406824f2184043708698b5d80e7173004d9719f80f->leave($__internal_b3bf2f68717cfd95bad8c7406824f2184043708698b5d80e7173004d9719f80f_prof);

        
        $__internal_59b6c4de4558e5ef7e9e2d690765715f114127cb05bf99bd50e176857940f873->leave($__internal_59b6c4de4558e5ef7e9e2d690765715f114127cb05bf99bd50e176857940f873_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_5f3cd28701761ff908ca3a6a07ec0a2f21e5b2443d3123a929b1cebe2d3dde8d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f3cd28701761ff908ca3a6a07ec0a2f21e5b2443d3123a929b1cebe2d3dde8d->enter($__internal_5f3cd28701761ff908ca3a6a07ec0a2f21e5b2443d3123a929b1cebe2d3dde8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f7edb47b0b80fb4199430b090b374cebcf4c9c961aea19969c2d0a8ccf019865 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7edb47b0b80fb4199430b090b374cebcf4c9c961aea19969c2d0a8ccf019865->enter($__internal_f7edb47b0b80fb4199430b090b374cebcf4c9c961aea19969c2d0a8ccf019865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Commercials:connect page</h1>
";
        
        $__internal_f7edb47b0b80fb4199430b090b374cebcf4c9c961aea19969c2d0a8ccf019865->leave($__internal_f7edb47b0b80fb4199430b090b374cebcf4c9c961aea19969c2d0a8ccf019865_prof);

        
        $__internal_5f3cd28701761ff908ca3a6a07ec0a2f21e5b2443d3123a929b1cebe2d3dde8d->leave($__internal_5f3cd28701761ff908ca3a6a07ec0a2f21e5b2443d3123a929b1cebe2d3dde8d_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Commercials:connect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block title %}AppBundle:Commercials:connect{% endblock %}

{% block body %}
<h1>Welcome to the Commercials:connect page</h1>
{% endblock %}
", "AppBundle:Commercials:connect.html.twig", "C:\\wamp\\www\\workshopB3\\api\\src\\AppBundle/Resources/views/Commercials/connect.html.twig");
    }
}
