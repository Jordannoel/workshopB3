<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_d0f7cba7771f43674cd7795c2c95d50753c80dcabcb1af1255fd8a0e0dda0a5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3c360c6f9b55191f4f33dcf32ad9de337ad8c2effd95ff426a564c36e66a4fb4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c360c6f9b55191f4f33dcf32ad9de337ad8c2effd95ff426a564c36e66a4fb4->enter($__internal_3c360c6f9b55191f4f33dcf32ad9de337ad8c2effd95ff426a564c36e66a4fb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_4154b283ed497de95c22ac06cc034138558adf9ffff3fd655c8951005543dba7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4154b283ed497de95c22ac06cc034138558adf9ffff3fd655c8951005543dba7->enter($__internal_4154b283ed497de95c22ac06cc034138558adf9ffff3fd655c8951005543dba7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3c360c6f9b55191f4f33dcf32ad9de337ad8c2effd95ff426a564c36e66a4fb4->leave($__internal_3c360c6f9b55191f4f33dcf32ad9de337ad8c2effd95ff426a564c36e66a4fb4_prof);

        
        $__internal_4154b283ed497de95c22ac06cc034138558adf9ffff3fd655c8951005543dba7->leave($__internal_4154b283ed497de95c22ac06cc034138558adf9ffff3fd655c8951005543dba7_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5c52ec411b159b819a0e878e1bfe67377b134ff8726426dffe6622ff6475c1f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c52ec411b159b819a0e878e1bfe67377b134ff8726426dffe6622ff6475c1f2->enter($__internal_5c52ec411b159b819a0e878e1bfe67377b134ff8726426dffe6622ff6475c1f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7bcdc7560f28e2a1b541868768a8542de8140137b864a345ac5966e11f878b63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bcdc7560f28e2a1b541868768a8542de8140137b864a345ac5966e11f878b63->enter($__internal_7bcdc7560f28e2a1b541868768a8542de8140137b864a345ac5966e11f878b63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7bcdc7560f28e2a1b541868768a8542de8140137b864a345ac5966e11f878b63->leave($__internal_7bcdc7560f28e2a1b541868768a8542de8140137b864a345ac5966e11f878b63_prof);

        
        $__internal_5c52ec411b159b819a0e878e1bfe67377b134ff8726426dffe6622ff6475c1f2->leave($__internal_5c52ec411b159b819a0e878e1bfe67377b134ff8726426dffe6622ff6475c1f2_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_70647e146df5cc127470d6fa880224490bc0c4c290ebe549c462c459414b403b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70647e146df5cc127470d6fa880224490bc0c4c290ebe549c462c459414b403b->enter($__internal_70647e146df5cc127470d6fa880224490bc0c4c290ebe549c462c459414b403b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_76945a32a9ad2c1fad1f6116b9c0b764d13afcd31fbe4fc3f7019a233df76e80 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76945a32a9ad2c1fad1f6116b9c0b764d13afcd31fbe4fc3f7019a233df76e80->enter($__internal_76945a32a9ad2c1fad1f6116b9c0b764d13afcd31fbe4fc3f7019a233df76e80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_76945a32a9ad2c1fad1f6116b9c0b764d13afcd31fbe4fc3f7019a233df76e80->leave($__internal_76945a32a9ad2c1fad1f6116b9c0b764d13afcd31fbe4fc3f7019a233df76e80_prof);

        
        $__internal_70647e146df5cc127470d6fa880224490bc0c4c290ebe549c462c459414b403b->leave($__internal_70647e146df5cc127470d6fa880224490bc0c4c290ebe549c462c459414b403b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c1f12af35f1cdaf3485ea2a1f660ad6106fadcaf365c65cd4f590d4c82955a38 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1f12af35f1cdaf3485ea2a1f660ad6106fadcaf365c65cd4f590d4c82955a38->enter($__internal_c1f12af35f1cdaf3485ea2a1f660ad6106fadcaf365c65cd4f590d4c82955a38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5681be487026a5411c5bbaa9e8c2dbe9c223b38ecadd834a5eea051ac9e89265 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5681be487026a5411c5bbaa9e8c2dbe9c223b38ecadd834a5eea051ac9e89265->enter($__internal_5681be487026a5411c5bbaa9e8c2dbe9c223b38ecadd834a5eea051ac9e89265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_5681be487026a5411c5bbaa9e8c2dbe9c223b38ecadd834a5eea051ac9e89265->leave($__internal_5681be487026a5411c5bbaa9e8c2dbe9c223b38ecadd834a5eea051ac9e89265_prof);

        
        $__internal_c1f12af35f1cdaf3485ea2a1f660ad6106fadcaf365c65cd4f590d4c82955a38->leave($__internal_c1f12af35f1cdaf3485ea2a1f660ad6106fadcaf365c65cd4f590d4c82955a38_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
