<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_435b145c8ef31e48213b21b1f35cb1988e3aabdd0f0a8db418b196ebf061e9c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0299cae3fa057eb944fcd78396d4cb3c021d640ca9bbfa9fbad68f4b67ce59b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0299cae3fa057eb944fcd78396d4cb3c021d640ca9bbfa9fbad68f4b67ce59b1->enter($__internal_0299cae3fa057eb944fcd78396d4cb3c021d640ca9bbfa9fbad68f4b67ce59b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_17e32ec66f43d7eec7f206033160f10a3d08281580ee56c2a2eab873085a754d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17e32ec66f43d7eec7f206033160f10a3d08281580ee56c2a2eab873085a754d->enter($__internal_17e32ec66f43d7eec7f206033160f10a3d08281580ee56c2a2eab873085a754d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_0299cae3fa057eb944fcd78396d4cb3c021d640ca9bbfa9fbad68f4b67ce59b1->leave($__internal_0299cae3fa057eb944fcd78396d4cb3c021d640ca9bbfa9fbad68f4b67ce59b1_prof);

        
        $__internal_17e32ec66f43d7eec7f206033160f10a3d08281580ee56c2a2eab873085a754d->leave($__internal_17e32ec66f43d7eec7f206033160f10a3d08281580ee56c2a2eab873085a754d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_attributes.html.php");
    }
}
