<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_49ce46171490374f7c700be45355443d552ded1e695eb6f34a49f9f9c80dc03b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5dfc754dce1439d05a25872ed3267642defc46218e04c1aaabfa515d7df62738 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dfc754dce1439d05a25872ed3267642defc46218e04c1aaabfa515d7df62738->enter($__internal_5dfc754dce1439d05a25872ed3267642defc46218e04c1aaabfa515d7df62738_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_40a23a6f1984579aec433373d90330beda2a431fb17f0ee6f255b92144f2facd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40a23a6f1984579aec433373d90330beda2a431fb17f0ee6f255b92144f2facd->enter($__internal_40a23a6f1984579aec433373d90330beda2a431fb17f0ee6f255b92144f2facd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_5dfc754dce1439d05a25872ed3267642defc46218e04c1aaabfa515d7df62738->leave($__internal_5dfc754dce1439d05a25872ed3267642defc46218e04c1aaabfa515d7df62738_prof);

        
        $__internal_40a23a6f1984579aec433373d90330beda2a431fb17f0ee6f255b92144f2facd->leave($__internal_40a23a6f1984579aec433373d90330beda2a431fb17f0ee6f255b92144f2facd_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
