<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_1ffbb21902518405bf59b7ec94ccffaf68c67c4a1b0ebaa4cce656079092e2c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf2869bc34729099e8fe16bb2e0e84a9cbfaac9d1572dce5a1a4e7b34d949bc2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf2869bc34729099e8fe16bb2e0e84a9cbfaac9d1572dce5a1a4e7b34d949bc2->enter($__internal_bf2869bc34729099e8fe16bb2e0e84a9cbfaac9d1572dce5a1a4e7b34d949bc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_4dfc27e8231af15f144dbf04435513be337f650991aadd727ab4786106be4a36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4dfc27e8231af15f144dbf04435513be337f650991aadd727ab4786106be4a36->enter($__internal_4dfc27e8231af15f144dbf04435513be337f650991aadd727ab4786106be4a36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_bf2869bc34729099e8fe16bb2e0e84a9cbfaac9d1572dce5a1a4e7b34d949bc2->leave($__internal_bf2869bc34729099e8fe16bb2e0e84a9cbfaac9d1572dce5a1a4e7b34d949bc2_prof);

        
        $__internal_4dfc27e8231af15f144dbf04435513be337f650991aadd727ab4786106be4a36->leave($__internal_4dfc27e8231af15f144dbf04435513be337f650991aadd727ab4786106be4a36_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_container_attributes.html.php");
    }
}
