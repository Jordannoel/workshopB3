<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_dfbbb742d790e4aa82f523cd4151318f9070a60a902ca3a1a54bb847823bafe1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46d7246acde8952ac81e569e781fbb9f77b4d285c5ec551681176118caee39f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46d7246acde8952ac81e569e781fbb9f77b4d285c5ec551681176118caee39f7->enter($__internal_46d7246acde8952ac81e569e781fbb9f77b4d285c5ec551681176118caee39f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_5b3dc472a432a4d0d9be7e62ff462581ce71cc0fabb87700af7399398b8f4b40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b3dc472a432a4d0d9be7e62ff462581ce71cc0fabb87700af7399398b8f4b40->enter($__internal_5b3dc472a432a4d0d9be7e62ff462581ce71cc0fabb87700af7399398b8f4b40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_46d7246acde8952ac81e569e781fbb9f77b4d285c5ec551681176118caee39f7->leave($__internal_46d7246acde8952ac81e569e781fbb9f77b4d285c5ec551681176118caee39f7_prof);

        
        $__internal_5b3dc472a432a4d0d9be7e62ff462581ce71cc0fabb87700af7399398b8f4b40->leave($__internal_5b3dc472a432a4d0d9be7e62ff462581ce71cc0fabb87700af7399398b8f4b40_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
