<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_f7fdca09f08d6aa76a8d11998759e2d61ba6bd61a992516eb13196f8db50ba09 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_88a652be06f47ff018cb182baaaaa70fb8e74339fd8daf440b86550e6f4a1a12 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88a652be06f47ff018cb182baaaaa70fb8e74339fd8daf440b86550e6f4a1a12->enter($__internal_88a652be06f47ff018cb182baaaaa70fb8e74339fd8daf440b86550e6f4a1a12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_f7f6308d597514d10358bf4cdfb07ca1efcffcaa41bb378d323eccf59d246458 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7f6308d597514d10358bf4cdfb07ca1efcffcaa41bb378d323eccf59d246458->enter($__internal_f7f6308d597514d10358bf4cdfb07ca1efcffcaa41bb378d323eccf59d246458_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_88a652be06f47ff018cb182baaaaa70fb8e74339fd8daf440b86550e6f4a1a12->leave($__internal_88a652be06f47ff018cb182baaaaa70fb8e74339fd8daf440b86550e6f4a1a12_prof);

        
        $__internal_f7f6308d597514d10358bf4cdfb07ca1efcffcaa41bb378d323eccf59d246458->leave($__internal_f7f6308d597514d10358bf4cdfb07ca1efcffcaa41bb378d323eccf59d246458_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_846261591c196f7dac15e2188521e0bd8e77de92186faf10ec94ae311e9bd056 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_846261591c196f7dac15e2188521e0bd8e77de92186faf10ec94ae311e9bd056->enter($__internal_846261591c196f7dac15e2188521e0bd8e77de92186faf10ec94ae311e9bd056_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_f0778776b6b54998fe32197927aac7c13e6888c3363a6170bccb0ca0cdefeac8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0778776b6b54998fe32197927aac7c13e6888c3363a6170bccb0ca0cdefeac8->enter($__internal_f0778776b6b54998fe32197927aac7c13e6888c3363a6170bccb0ca0cdefeac8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_f0778776b6b54998fe32197927aac7c13e6888c3363a6170bccb0ca0cdefeac8->leave($__internal_f0778776b6b54998fe32197927aac7c13e6888c3363a6170bccb0ca0cdefeac8_prof);

        
        $__internal_846261591c196f7dac15e2188521e0bd8e77de92186faf10ec94ae311e9bd056->leave($__internal_846261591c196f7dac15e2188521e0bd8e77de92186faf10ec94ae311e9bd056_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_d96e3e638e2966e6fd0c815e8c3363df7ad8a0c1f75c1f45c43ee3505a358865 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d96e3e638e2966e6fd0c815e8c3363df7ad8a0c1f75c1f45c43ee3505a358865->enter($__internal_d96e3e638e2966e6fd0c815e8c3363df7ad8a0c1f75c1f45c43ee3505a358865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a79dca8c5b8232b35576bc64b144943d2ea49297e0cc5b9f80c4896729d46484 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a79dca8c5b8232b35576bc64b144943d2ea49297e0cc5b9f80c4896729d46484->enter($__internal_a79dca8c5b8232b35576bc64b144943d2ea49297e0cc5b9f80c4896729d46484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_a79dca8c5b8232b35576bc64b144943d2ea49297e0cc5b9f80c4896729d46484->leave($__internal_a79dca8c5b8232b35576bc64b144943d2ea49297e0cc5b9f80c4896729d46484_prof);

        
        $__internal_d96e3e638e2966e6fd0c815e8c3363df7ad8a0c1f75c1f45c43ee3505a358865->leave($__internal_d96e3e638e2966e6fd0c815e8c3363df7ad8a0c1f75c1f45c43ee3505a358865_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
