<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_33727356872726efe1c610ed9d3acd7eed028a45157b20cc4d3ac9278833493f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_02b88075dfea5e9db6e3e1b5fd45002b126ee49a656a034625c039fc89464bc9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02b88075dfea5e9db6e3e1b5fd45002b126ee49a656a034625c039fc89464bc9->enter($__internal_02b88075dfea5e9db6e3e1b5fd45002b126ee49a656a034625c039fc89464bc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_1b17e0401a531f57a38d4060fef2b96bdac38e61ece984df304bdfaab402c50b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b17e0401a531f57a38d4060fef2b96bdac38e61ece984df304bdfaab402c50b->enter($__internal_1b17e0401a531f57a38d4060fef2b96bdac38e61ece984df304bdfaab402c50b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_02b88075dfea5e9db6e3e1b5fd45002b126ee49a656a034625c039fc89464bc9->leave($__internal_02b88075dfea5e9db6e3e1b5fd45002b126ee49a656a034625c039fc89464bc9_prof);

        
        $__internal_1b17e0401a531f57a38d4060fef2b96bdac38e61ece984df304bdfaab402c50b->leave($__internal_1b17e0401a531f57a38d4060fef2b96bdac38e61ece984df304bdfaab402c50b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_160bcaa0a5d26ee27ac61f04a2ee9fbd0008ea47c47b8439a2ef03861ab32798 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_160bcaa0a5d26ee27ac61f04a2ee9fbd0008ea47c47b8439a2ef03861ab32798->enter($__internal_160bcaa0a5d26ee27ac61f04a2ee9fbd0008ea47c47b8439a2ef03861ab32798_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_d262cc49a8689fd639e1e2f04d6b7b12eeba0d1ccac2099cba8fb01feb21d4c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d262cc49a8689fd639e1e2f04d6b7b12eeba0d1ccac2099cba8fb01feb21d4c6->enter($__internal_d262cc49a8689fd639e1e2f04d6b7b12eeba0d1ccac2099cba8fb01feb21d4c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d262cc49a8689fd639e1e2f04d6b7b12eeba0d1ccac2099cba8fb01feb21d4c6->leave($__internal_d262cc49a8689fd639e1e2f04d6b7b12eeba0d1ccac2099cba8fb01feb21d4c6_prof);

        
        $__internal_160bcaa0a5d26ee27ac61f04a2ee9fbd0008ea47c47b8439a2ef03861ab32798->leave($__internal_160bcaa0a5d26ee27ac61f04a2ee9fbd0008ea47c47b8439a2ef03861ab32798_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_835797371cb3f820ec2cac1e3c37b0504d59ff68d9e6ed529c18abca861abd2a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_835797371cb3f820ec2cac1e3c37b0504d59ff68d9e6ed529c18abca861abd2a->enter($__internal_835797371cb3f820ec2cac1e3c37b0504d59ff68d9e6ed529c18abca861abd2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_1464282dad3ea8af7cc1a21175a05d5a7059cffdb2a3366485117d6e7391d2b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1464282dad3ea8af7cc1a21175a05d5a7059cffdb2a3366485117d6e7391d2b3->enter($__internal_1464282dad3ea8af7cc1a21175a05d5a7059cffdb2a3366485117d6e7391d2b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_1464282dad3ea8af7cc1a21175a05d5a7059cffdb2a3366485117d6e7391d2b3->leave($__internal_1464282dad3ea8af7cc1a21175a05d5a7059cffdb2a3366485117d6e7391d2b3_prof);

        
        $__internal_835797371cb3f820ec2cac1e3c37b0504d59ff68d9e6ed529c18abca861abd2a->leave($__internal_835797371cb3f820ec2cac1e3c37b0504d59ff68d9e6ed529c18abca861abd2a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_78b140737784ad14efb153c11aa744185b2b19eaf9a42342be54f7940bfd0de2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78b140737784ad14efb153c11aa744185b2b19eaf9a42342be54f7940bfd0de2->enter($__internal_78b140737784ad14efb153c11aa744185b2b19eaf9a42342be54f7940bfd0de2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e5cbd20f3389908cdc492def62cacbc5b89f30602ad4a1c57820b9be54526ecd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5cbd20f3389908cdc492def62cacbc5b89f30602ad4a1c57820b9be54526ecd->enter($__internal_e5cbd20f3389908cdc492def62cacbc5b89f30602ad4a1c57820b9be54526ecd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e5cbd20f3389908cdc492def62cacbc5b89f30602ad4a1c57820b9be54526ecd->leave($__internal_e5cbd20f3389908cdc492def62cacbc5b89f30602ad4a1c57820b9be54526ecd_prof);

        
        $__internal_78b140737784ad14efb153c11aa744185b2b19eaf9a42342be54f7940bfd0de2->leave($__internal_78b140737784ad14efb153c11aa744185b2b19eaf9a42342be54f7940bfd0de2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
