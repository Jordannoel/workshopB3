<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_50d7596cc7694e7be7cb1c574fe4a4bfb444aae630706bfcc6c49ff0c638a4ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23b1bc336416eaa69e5ad2a5b468fedb2b49646d42cc36e22d9d95b85f798e4e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23b1bc336416eaa69e5ad2a5b468fedb2b49646d42cc36e22d9d95b85f798e4e->enter($__internal_23b1bc336416eaa69e5ad2a5b468fedb2b49646d42cc36e22d9d95b85f798e4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_e3a81941dcd0f223fc1b4fe30fa92559123429370128108e98b2bb7073a7a748 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3a81941dcd0f223fc1b4fe30fa92559123429370128108e98b2bb7073a7a748->enter($__internal_e3a81941dcd0f223fc1b4fe30fa92559123429370128108e98b2bb7073a7a748_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_23b1bc336416eaa69e5ad2a5b468fedb2b49646d42cc36e22d9d95b85f798e4e->leave($__internal_23b1bc336416eaa69e5ad2a5b468fedb2b49646d42cc36e22d9d95b85f798e4e_prof);

        
        $__internal_e3a81941dcd0f223fc1b4fe30fa92559123429370128108e98b2bb7073a7a748->leave($__internal_e3a81941dcd0f223fc1b4fe30fa92559123429370128108e98b2bb7073a7a748_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
