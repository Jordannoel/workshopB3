<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_4c80cbbc4f6e251443e356fa4168c1192c12b7acf878024bfb7970d6dfa88fc0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc72f9af96a16fe059360cfb945227af328c15607c6cc96876419dc82d08c63f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc72f9af96a16fe059360cfb945227af328c15607c6cc96876419dc82d08c63f->enter($__internal_dc72f9af96a16fe059360cfb945227af328c15607c6cc96876419dc82d08c63f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_65fe2e56d8c89ba220bedd6c336672d1b82ad4fab912a0ad623486a02f4ab656 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65fe2e56d8c89ba220bedd6c336672d1b82ad4fab912a0ad623486a02f4ab656->enter($__internal_65fe2e56d8c89ba220bedd6c336672d1b82ad4fab912a0ad623486a02f4ab656_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_dc72f9af96a16fe059360cfb945227af328c15607c6cc96876419dc82d08c63f->leave($__internal_dc72f9af96a16fe059360cfb945227af328c15607c6cc96876419dc82d08c63f_prof);

        
        $__internal_65fe2e56d8c89ba220bedd6c336672d1b82ad4fab912a0ad623486a02f4ab656->leave($__internal_65fe2e56d8c89ba220bedd6c336672d1b82ad4fab912a0ad623486a02f4ab656_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_d243a2f97c98dcd252ea9cc43575a3277be39173e7344775b98c54d630113bc0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d243a2f97c98dcd252ea9cc43575a3277be39173e7344775b98c54d630113bc0->enter($__internal_d243a2f97c98dcd252ea9cc43575a3277be39173e7344775b98c54d630113bc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_776c522a7ecb9c57457637270e52140f24ddd14bbf3edfed64692f38a0bfb5e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_776c522a7ecb9c57457637270e52140f24ddd14bbf3edfed64692f38a0bfb5e6->enter($__internal_776c522a7ecb9c57457637270e52140f24ddd14bbf3edfed64692f38a0bfb5e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_776c522a7ecb9c57457637270e52140f24ddd14bbf3edfed64692f38a0bfb5e6->leave($__internal_776c522a7ecb9c57457637270e52140f24ddd14bbf3edfed64692f38a0bfb5e6_prof);

        
        $__internal_d243a2f97c98dcd252ea9cc43575a3277be39173e7344775b98c54d630113bc0->leave($__internal_d243a2f97c98dcd252ea9cc43575a3277be39173e7344775b98c54d630113bc0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
