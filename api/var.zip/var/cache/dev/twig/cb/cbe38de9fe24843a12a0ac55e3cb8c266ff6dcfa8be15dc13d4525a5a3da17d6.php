<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_e631ba8ece24395f64cd6247ad5867ec1156de88eae3b808808edf67d351fc68 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_581bf5da7da29afdc450eec4bc349053ff807befb1b47c0d9c39336784898616 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_581bf5da7da29afdc450eec4bc349053ff807befb1b47c0d9c39336784898616->enter($__internal_581bf5da7da29afdc450eec4bc349053ff807befb1b47c0d9c39336784898616_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        $__internal_cd4dd88fc9139d559472e95d98f760e2f0762f5b0df63dbd76f4d65345e1704b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd4dd88fc9139d559472e95d98f760e2f0762f5b0df63dbd76f4d65345e1704b->enter($__internal_cd4dd88fc9139d559472e95d98f760e2f0762f5b0df63dbd76f4d65345e1704b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_581bf5da7da29afdc450eec4bc349053ff807befb1b47c0d9c39336784898616->leave($__internal_581bf5da7da29afdc450eec4bc349053ff807befb1b47c0d9c39336784898616_prof);

        
        $__internal_cd4dd88fc9139d559472e95d98f760e2f0762f5b0df63dbd76f4d65345e1704b->leave($__internal_cd4dd88fc9139d559472e95d98f760e2f0762f5b0df63dbd76f4d65345e1704b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
", "@Framework/Form/range_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\range_widget.html.php");
    }
}
