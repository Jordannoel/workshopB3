<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_20216c96a4d302674d1155eb84427ce0bde9502358e4e2a8c8bb1f0a203e2008 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a53f7c6194ee3327d06b43777dac8e77be90c11a842388f654bb17fdba227da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a53f7c6194ee3327d06b43777dac8e77be90c11a842388f654bb17fdba227da->enter($__internal_6a53f7c6194ee3327d06b43777dac8e77be90c11a842388f654bb17fdba227da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_9646e005587a4ed6b4d279b39acd3585803df47b3477e41c9b33f7542ad62763 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9646e005587a4ed6b4d279b39acd3585803df47b3477e41c9b33f7542ad62763->enter($__internal_9646e005587a4ed6b4d279b39acd3585803df47b3477e41c9b33f7542ad62763_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_6a53f7c6194ee3327d06b43777dac8e77be90c11a842388f654bb17fdba227da->leave($__internal_6a53f7c6194ee3327d06b43777dac8e77be90c11a842388f654bb17fdba227da_prof);

        
        $__internal_9646e005587a4ed6b4d279b39acd3585803df47b3477e41c9b33f7542ad62763->leave($__internal_9646e005587a4ed6b4d279b39acd3585803df47b3477e41c9b33f7542ad62763_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.js.twig");
    }
}
