<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_0d229daf3099657ec73e67a30e4e4c649e1847f887c7836ee2e7badbb5dc015c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fff97861c3e1ba987d537e33ae6337b8c1d2e3cdacd624efd192c66f864b3ebc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fff97861c3e1ba987d537e33ae6337b8c1d2e3cdacd624efd192c66f864b3ebc->enter($__internal_fff97861c3e1ba987d537e33ae6337b8c1d2e3cdacd624efd192c66f864b3ebc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_6d8ccd50ad3e77cc2db7b4282b1595d3cb2e1bdc6c1c23411803b7c2734ef0dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d8ccd50ad3e77cc2db7b4282b1595d3cb2e1bdc6c1c23411803b7c2734ef0dc->enter($__internal_6d8ccd50ad3e77cc2db7b4282b1595d3cb2e1bdc6c1c23411803b7c2734ef0dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_fff97861c3e1ba987d537e33ae6337b8c1d2e3cdacd624efd192c66f864b3ebc->leave($__internal_fff97861c3e1ba987d537e33ae6337b8c1d2e3cdacd624efd192c66f864b3ebc_prof);

        
        $__internal_6d8ccd50ad3e77cc2db7b4282b1595d3cb2e1bdc6c1c23411803b7c2734ef0dc->leave($__internal_6d8ccd50ad3e77cc2db7b4282b1595d3cb2e1bdc6c1c23411803b7c2734ef0dc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
