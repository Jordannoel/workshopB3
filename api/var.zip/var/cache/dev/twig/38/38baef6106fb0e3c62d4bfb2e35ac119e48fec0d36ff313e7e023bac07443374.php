<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_288584128327698ed0e6b6c25dbb34fb794c43c6f188d96db5d4ff24feacf281 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d04096be4891f877a38e30aa765a39be92154479e4f6464048ec5e821445db17 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d04096be4891f877a38e30aa765a39be92154479e4f6464048ec5e821445db17->enter($__internal_d04096be4891f877a38e30aa765a39be92154479e4f6464048ec5e821445db17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_1e06d67cf4a9e31959d14d373268550e98efb95b5e943a1369885ecab3801305 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e06d67cf4a9e31959d14d373268550e98efb95b5e943a1369885ecab3801305->enter($__internal_1e06d67cf4a9e31959d14d373268550e98efb95b5e943a1369885ecab3801305_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_d04096be4891f877a38e30aa765a39be92154479e4f6464048ec5e821445db17->leave($__internal_d04096be4891f877a38e30aa765a39be92154479e4f6464048ec5e821445db17_prof);

        
        $__internal_1e06d67cf4a9e31959d14d373268550e98efb95b5e943a1369885ecab3801305->leave($__internal_1e06d67cf4a9e31959d14d373268550e98efb95b5e943a1369885ecab3801305_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_widget_compound.html.php");
    }
}
