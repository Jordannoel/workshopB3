<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_276df2873d3e3e445a70600a6e2e89765a4ecc24d46617fb964713a995768832 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8cb3c0991b2b53246ad09eecbf8bf7eaed4c04d621280798620c020899ecaf48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8cb3c0991b2b53246ad09eecbf8bf7eaed4c04d621280798620c020899ecaf48->enter($__internal_8cb3c0991b2b53246ad09eecbf8bf7eaed4c04d621280798620c020899ecaf48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_306c8265e79cabe97433154df5b63a6522eeb1b5dbbfea2b3a989d65fb818fd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_306c8265e79cabe97433154df5b63a6522eeb1b5dbbfea2b3a989d65fb818fd6->enter($__internal_306c8265e79cabe97433154df5b63a6522eeb1b5dbbfea2b3a989d65fb818fd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_8cb3c0991b2b53246ad09eecbf8bf7eaed4c04d621280798620c020899ecaf48->leave($__internal_8cb3c0991b2b53246ad09eecbf8bf7eaed4c04d621280798620c020899ecaf48_prof);

        
        $__internal_306c8265e79cabe97433154df5b63a6522eeb1b5dbbfea2b3a989d65fb818fd6->leave($__internal_306c8265e79cabe97433154df5b63a6522eeb1b5dbbfea2b3a989d65fb818fd6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
