<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_c3e618d2514d3486c3a0a566f2436c6b5e37b33bfeda0f768f43b15318c35872 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c2adf27c156650fe1163b9b0cc7e75d2b665183822249f178f4c69496a3cf439 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2adf27c156650fe1163b9b0cc7e75d2b665183822249f178f4c69496a3cf439->enter($__internal_c2adf27c156650fe1163b9b0cc7e75d2b665183822249f178f4c69496a3cf439_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_50214834defa0ef0b1cc4a182b218f2e14be88afad2f795e737d37d470c85863 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50214834defa0ef0b1cc4a182b218f2e14be88afad2f795e737d37d470c85863->enter($__internal_50214834defa0ef0b1cc4a182b218f2e14be88afad2f795e737d37d470c85863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_c2adf27c156650fe1163b9b0cc7e75d2b665183822249f178f4c69496a3cf439->leave($__internal_c2adf27c156650fe1163b9b0cc7e75d2b665183822249f178f4c69496a3cf439_prof);

        
        $__internal_50214834defa0ef0b1cc4a182b218f2e14be88afad2f795e737d37d470c85863->leave($__internal_50214834defa0ef0b1cc4a182b218f2e14be88afad2f795e737d37d470c85863_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_simple.html.php");
    }
}
