<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_f4246ef443ace8d843686cc2b3e4557b6a20284a1b1cce143e25265565eb4edf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43ad5a5e37e1334a747f208ca6d8de9d10024f8ba0ca3e7b8cfe4b3b5d8e43d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_43ad5a5e37e1334a747f208ca6d8de9d10024f8ba0ca3e7b8cfe4b3b5d8e43d3->enter($__internal_43ad5a5e37e1334a747f208ca6d8de9d10024f8ba0ca3e7b8cfe4b3b5d8e43d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_e62875bc83be22935fb643eeb465e38c0b3bd10c9038766cf5226ad78d2afb8b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e62875bc83be22935fb643eeb465e38c0b3bd10c9038766cf5226ad78d2afb8b->enter($__internal_e62875bc83be22935fb643eeb465e38c0b3bd10c9038766cf5226ad78d2afb8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_43ad5a5e37e1334a747f208ca6d8de9d10024f8ba0ca3e7b8cfe4b3b5d8e43d3->leave($__internal_43ad5a5e37e1334a747f208ca6d8de9d10024f8ba0ca3e7b8cfe4b3b5d8e43d3_prof);

        
        $__internal_e62875bc83be22935fb643eeb465e38c0b3bd10c9038766cf5226ad78d2afb8b->leave($__internal_e62875bc83be22935fb643eeb465e38c0b3bd10c9038766cf5226ad78d2afb8b_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_bd27eeee0dcf1d4e36785e863a06ff823c30ae35e69359d65bc0a9eb99ba91be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd27eeee0dcf1d4e36785e863a06ff823c30ae35e69359d65bc0a9eb99ba91be->enter($__internal_bd27eeee0dcf1d4e36785e863a06ff823c30ae35e69359d65bc0a9eb99ba91be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8c1bf41543f7c13b573fd2f79a8090792e72cce2bb9b2aed8a57859a71b842ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c1bf41543f7c13b573fd2f79a8090792e72cce2bb9b2aed8a57859a71b842ab->enter($__internal_8c1bf41543f7c13b573fd2f79a8090792e72cce2bb9b2aed8a57859a71b842ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_8c1bf41543f7c13b573fd2f79a8090792e72cce2bb9b2aed8a57859a71b842ab->leave($__internal_8c1bf41543f7c13b573fd2f79a8090792e72cce2bb9b2aed8a57859a71b842ab_prof);

        
        $__internal_bd27eeee0dcf1d4e36785e863a06ff823c30ae35e69359d65bc0a9eb99ba91be->leave($__internal_bd27eeee0dcf1d4e36785e863a06ff823c30ae35e69359d65bc0a9eb99ba91be_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
