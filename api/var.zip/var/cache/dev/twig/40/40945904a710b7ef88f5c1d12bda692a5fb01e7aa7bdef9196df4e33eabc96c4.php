<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_496361a52fc8271d65235d4851230ebdc00c8896318ee973e165ea284f8b479c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_677c74d106a4aff1befb34663bf18b95eacebeb487ca538cae332fb9720f1cd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_677c74d106a4aff1befb34663bf18b95eacebeb487ca538cae332fb9720f1cd3->enter($__internal_677c74d106a4aff1befb34663bf18b95eacebeb487ca538cae332fb9720f1cd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_b0732dab8736ece231cb09f8e6f4216b53d648d6854ace955a05ef2eccb044d6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0732dab8736ece231cb09f8e6f4216b53d648d6854ace955a05ef2eccb044d6->enter($__internal_b0732dab8736ece231cb09f8e6f4216b53d648d6854ace955a05ef2eccb044d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_677c74d106a4aff1befb34663bf18b95eacebeb487ca538cae332fb9720f1cd3->leave($__internal_677c74d106a4aff1befb34663bf18b95eacebeb487ca538cae332fb9720f1cd3_prof);

        
        $__internal_b0732dab8736ece231cb09f8e6f4216b53d648d6854ace955a05ef2eccb044d6->leave($__internal_b0732dab8736ece231cb09f8e6f4216b53d648d6854ace955a05ef2eccb044d6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\datetime_widget.html.php");
    }
}
