<?php

/* TwigBundle:Exception:error.json.twig */
class __TwigTemplate_80066e07492c5b29241911c3f9f6b2aeb9e45816969a125a5eca17b0129371b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3eca09ec56959425a9d8dcf0131fc57626e2852a3d40b052f0b8eb1e1229028e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3eca09ec56959425a9d8dcf0131fc57626e2852a3d40b052f0b8eb1e1229028e->enter($__internal_3eca09ec56959425a9d8dcf0131fc57626e2852a3d40b052f0b8eb1e1229028e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        $__internal_f979318f1a57fcf6fbc9e2875598a98cff18563b9b65a6e4285182bf9e2a8925 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f979318f1a57fcf6fbc9e2875598a98cff18563b9b65a6e4285182bf9e2a8925->enter($__internal_f979318f1a57fcf6fbc9e2875598a98cff18563b9b65a6e4285182bf9e2a8925_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_3eca09ec56959425a9d8dcf0131fc57626e2852a3d40b052f0b8eb1e1229028e->leave($__internal_3eca09ec56959425a9d8dcf0131fc57626e2852a3d40b052f0b8eb1e1229028e_prof);

        
        $__internal_f979318f1a57fcf6fbc9e2875598a98cff18563b9b65a6e4285182bf9e2a8925->leave($__internal_f979318f1a57fcf6fbc9e2875598a98cff18563b9b65a6e4285182bf9e2a8925_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "TwigBundle:Exception:error.json.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.json.twig");
    }
}
