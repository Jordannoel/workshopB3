<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_5a3aafe480d68cbaaea1209d15a1bb8e79c8a05cf42395e6d6956707043cfc66 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fec61365109705e51c0f0cb06f9166b4031ef2450bae6ae52693b6b80373e68d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fec61365109705e51c0f0cb06f9166b4031ef2450bae6ae52693b6b80373e68d->enter($__internal_fec61365109705e51c0f0cb06f9166b4031ef2450bae6ae52693b6b80373e68d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_92c70abfea58fb703b9d935abcf3ef0e8728a426bcf84ded0ad8f547bdc9012d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92c70abfea58fb703b9d935abcf3ef0e8728a426bcf84ded0ad8f547bdc9012d->enter($__internal_92c70abfea58fb703b9d935abcf3ef0e8728a426bcf84ded0ad8f547bdc9012d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_fec61365109705e51c0f0cb06f9166b4031ef2450bae6ae52693b6b80373e68d->leave($__internal_fec61365109705e51c0f0cb06f9166b4031ef2450bae6ae52693b6b80373e68d_prof);

        
        $__internal_92c70abfea58fb703b9d935abcf3ef0e8728a426bcf84ded0ad8f547bdc9012d->leave($__internal_92c70abfea58fb703b9d935abcf3ef0e8728a426bcf84ded0ad8f547bdc9012d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
