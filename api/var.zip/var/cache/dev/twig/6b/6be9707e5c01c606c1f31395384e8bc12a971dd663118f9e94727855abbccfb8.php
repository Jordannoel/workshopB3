<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_357227969312bed03233219884535bf216544de5fcb52b544286d29e8d46c9a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e3ff1a53b0f4a3eb8b56a3dda54077cdae389f6b8c31aaa2719c71cc331dead9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e3ff1a53b0f4a3eb8b56a3dda54077cdae389f6b8c31aaa2719c71cc331dead9->enter($__internal_e3ff1a53b0f4a3eb8b56a3dda54077cdae389f6b8c31aaa2719c71cc331dead9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_3d8869628827dd0303b2a4dadaa868ae1bda348712b4cc5bc2d17b1e798089eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d8869628827dd0303b2a4dadaa868ae1bda348712b4cc5bc2d17b1e798089eb->enter($__internal_3d8869628827dd0303b2a4dadaa868ae1bda348712b4cc5bc2d17b1e798089eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => ($context["status_code"] ?? $this->getContext($context, "status_code")), "message" => ($context["status_text"] ?? $this->getContext($context, "status_text")), "exception" => $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_e3ff1a53b0f4a3eb8b56a3dda54077cdae389f6b8c31aaa2719c71cc331dead9->leave($__internal_e3ff1a53b0f4a3eb8b56a3dda54077cdae389f6b8c31aaa2719c71cc331dead9_prof);

        
        $__internal_3d8869628827dd0303b2a4dadaa868ae1bda348712b4cc5bc2d17b1e798089eb->leave($__internal_3d8869628827dd0303b2a4dadaa868ae1bda348712b4cc5bc2d17b1e798089eb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
