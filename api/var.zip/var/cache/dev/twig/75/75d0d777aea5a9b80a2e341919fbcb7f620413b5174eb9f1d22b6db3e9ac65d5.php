<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_d0ea433c954008cc98fc4961ee87e62ea394532fe1ad525075d74e0fd9dc626d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22a894ed0fa70381653be826e278a39af907702dd28242922fc60ec225b96868 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22a894ed0fa70381653be826e278a39af907702dd28242922fc60ec225b96868->enter($__internal_22a894ed0fa70381653be826e278a39af907702dd28242922fc60ec225b96868_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_24125043c52dbbcdb7c25a30ce6359faa2791a0c6fbcbff2bdaa08442fd85ae0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_24125043c52dbbcdb7c25a30ce6359faa2791a0c6fbcbff2bdaa08442fd85ae0->enter($__internal_24125043c52dbbcdb7c25a30ce6359faa2791a0c6fbcbff2bdaa08442fd85ae0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22a894ed0fa70381653be826e278a39af907702dd28242922fc60ec225b96868->leave($__internal_22a894ed0fa70381653be826e278a39af907702dd28242922fc60ec225b96868_prof);

        
        $__internal_24125043c52dbbcdb7c25a30ce6359faa2791a0c6fbcbff2bdaa08442fd85ae0->leave($__internal_24125043c52dbbcdb7c25a30ce6359faa2791a0c6fbcbff2bdaa08442fd85ae0_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_18d3529e932d2d5f6557074166d66705ed8891e679ad7437020339bd9497c324 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18d3529e932d2d5f6557074166d66705ed8891e679ad7437020339bd9497c324->enter($__internal_18d3529e932d2d5f6557074166d66705ed8891e679ad7437020339bd9497c324_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_5858e26d1ad955fe4921f280d47ea49a50aa523eeb6a1af1f3a81b7edd4f1c78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5858e26d1ad955fe4921f280d47ea49a50aa523eeb6a1af1f3a81b7edd4f1c78->enter($__internal_5858e26d1ad955fe4921f280d47ea49a50aa523eeb6a1af1f3a81b7edd4f1c78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_5858e26d1ad955fe4921f280d47ea49a50aa523eeb6a1af1f3a81b7edd4f1c78->leave($__internal_5858e26d1ad955fe4921f280d47ea49a50aa523eeb6a1af1f3a81b7edd4f1c78_prof);

        
        $__internal_18d3529e932d2d5f6557074166d66705ed8891e679ad7437020339bd9497c324->leave($__internal_18d3529e932d2d5f6557074166d66705ed8891e679ad7437020339bd9497c324_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_89de07a52e554c6aa475f2773ab3886f41b7b69ff03df2a95f59384f1e0af3dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89de07a52e554c6aa475f2773ab3886f41b7b69ff03df2a95f59384f1e0af3dd->enter($__internal_89de07a52e554c6aa475f2773ab3886f41b7b69ff03df2a95f59384f1e0af3dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b96158fd5889d15678cd3cfc0db8a6c9ea8cdebcb7f9de2200324bfc3675935c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b96158fd5889d15678cd3cfc0db8a6c9ea8cdebcb7f9de2200324bfc3675935c->enter($__internal_b96158fd5889d15678cd3cfc0db8a6c9ea8cdebcb7f9de2200324bfc3675935c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_b96158fd5889d15678cd3cfc0db8a6c9ea8cdebcb7f9de2200324bfc3675935c->leave($__internal_b96158fd5889d15678cd3cfc0db8a6c9ea8cdebcb7f9de2200324bfc3675935c_prof);

        
        $__internal_89de07a52e554c6aa475f2773ab3886f41b7b69ff03df2a95f59384f1e0af3dd->leave($__internal_89de07a52e554c6aa475f2773ab3886f41b7b69ff03df2a95f59384f1e0af3dd_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_395f643ac733fe2b72516a4e65ee2b948d27bcab612c6d5144188926dafa9ed8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_395f643ac733fe2b72516a4e65ee2b948d27bcab612c6d5144188926dafa9ed8->enter($__internal_395f643ac733fe2b72516a4e65ee2b948d27bcab612c6d5144188926dafa9ed8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_19d78dd2155dd374a99c51980907ab935c9be6f2f906de7d09407ff70dde25b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_19d78dd2155dd374a99c51980907ab935c9be6f2f906de7d09407ff70dde25b5->enter($__internal_19d78dd2155dd374a99c51980907ab935c9be6f2f906de7d09407ff70dde25b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_19d78dd2155dd374a99c51980907ab935c9be6f2f906de7d09407ff70dde25b5->leave($__internal_19d78dd2155dd374a99c51980907ab935c9be6f2f906de7d09407ff70dde25b5_prof);

        
        $__internal_395f643ac733fe2b72516a4e65ee2b948d27bcab612c6d5144188926dafa9ed8->leave($__internal_395f643ac733fe2b72516a4e65ee2b948d27bcab612c6d5144188926dafa9ed8_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
