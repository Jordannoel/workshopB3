<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_e4cdfb6cc83c59090c82f77816c237694f97bb202e4656d04f174aca8b7958db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0af1836d3194641bf2e3ab1a33675043ca362a30b98cf89424abea274594f49a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0af1836d3194641bf2e3ab1a33675043ca362a30b98cf89424abea274594f49a->enter($__internal_0af1836d3194641bf2e3ab1a33675043ca362a30b98cf89424abea274594f49a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_cae0f616da78e31f5a7b7c47f7bd16d3477d43f48b90127c2b7f9ec44162de26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cae0f616da78e31f5a7b7c47f7bd16d3477d43f48b90127c2b7f9ec44162de26->enter($__internal_cae0f616da78e31f5a7b7c47f7bd16d3477d43f48b90127c2b7f9ec44162de26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_0af1836d3194641bf2e3ab1a33675043ca362a30b98cf89424abea274594f49a->leave($__internal_0af1836d3194641bf2e3ab1a33675043ca362a30b98cf89424abea274594f49a_prof);

        
        $__internal_cae0f616da78e31f5a7b7c47f7bd16d3477d43f48b90127c2b7f9ec44162de26->leave($__internal_cae0f616da78e31f5a7b7c47f7bd16d3477d43f48b90127c2b7f9ec44162de26_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "TwigBundle:Exception:exception.atom.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
