<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_3a46f5d3cf8ca8ca73488b5ae09e0be6877e692d893e92b012c33fb760462219 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2bec7a3c412fedf5c677ba9106fbb1ccd949a16310c47939a8049d333f4d4aed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2bec7a3c412fedf5c677ba9106fbb1ccd949a16310c47939a8049d333f4d4aed->enter($__internal_2bec7a3c412fedf5c677ba9106fbb1ccd949a16310c47939a8049d333f4d4aed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_09c8ef5e885271096a3be290b3c5bd10d550ae3fb67d33eb560b2bd069a237be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09c8ef5e885271096a3be290b3c5bd10d550ae3fb67d33eb560b2bd069a237be->enter($__internal_09c8ef5e885271096a3be290b3c5bd10d550ae3fb67d33eb560b2bd069a237be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_2bec7a3c412fedf5c677ba9106fbb1ccd949a16310c47939a8049d333f4d4aed->leave($__internal_2bec7a3c412fedf5c677ba9106fbb1ccd949a16310c47939a8049d333f4d4aed_prof);

        
        $__internal_09c8ef5e885271096a3be290b3c5bd10d550ae3fb67d33eb560b2bd069a237be->leave($__internal_09c8ef5e885271096a3be290b3c5bd10d550ae3fb67d33eb560b2bd069a237be_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
