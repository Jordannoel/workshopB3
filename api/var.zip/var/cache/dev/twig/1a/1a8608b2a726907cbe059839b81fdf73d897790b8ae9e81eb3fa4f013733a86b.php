<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_5be44fa5309bb4e94ecc22454556e1cd38606561dd24f6d3e435f8c65c03acfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d76435d6800df0a323dd8c6fa00006c8e34a6e357cb2710ad8503ea09536c17f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d76435d6800df0a323dd8c6fa00006c8e34a6e357cb2710ad8503ea09536c17f->enter($__internal_d76435d6800df0a323dd8c6fa00006c8e34a6e357cb2710ad8503ea09536c17f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_c401d0ad9a957288f283b9a60d0e43f321a802f8ea6fcb10417642510f447e57 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c401d0ad9a957288f283b9a60d0e43f321a802f8ea6fcb10417642510f447e57->enter($__internal_c401d0ad9a957288f283b9a60d0e43f321a802f8ea6fcb10417642510f447e57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_d76435d6800df0a323dd8c6fa00006c8e34a6e357cb2710ad8503ea09536c17f->leave($__internal_d76435d6800df0a323dd8c6fa00006c8e34a6e357cb2710ad8503ea09536c17f_prof);

        
        $__internal_c401d0ad9a957288f283b9a60d0e43f321a802f8ea6fcb10417642510f447e57->leave($__internal_c401d0ad9a957288f283b9a60d0e43f321a802f8ea6fcb10417642510f447e57_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
