<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_8cb8dd1eaf50f41c0f18025fa2d30798b2d605186fe8effb0f052950dc68fecd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a8d8ec501060f0e045e228863ea42fe7ca4e9044b9b1b80e16c22ffd00150ae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a8d8ec501060f0e045e228863ea42fe7ca4e9044b9b1b80e16c22ffd00150ae->enter($__internal_2a8d8ec501060f0e045e228863ea42fe7ca4e9044b9b1b80e16c22ffd00150ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_6dec68ff8eb880ecd83b06dd2e046090f70231f3a91346ae0fa1b22d8448553e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6dec68ff8eb880ecd83b06dd2e046090f70231f3a91346ae0fa1b22d8448553e->enter($__internal_6dec68ff8eb880ecd83b06dd2e046090f70231f3a91346ae0fa1b22d8448553e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_2a8d8ec501060f0e045e228863ea42fe7ca4e9044b9b1b80e16c22ffd00150ae->leave($__internal_2a8d8ec501060f0e045e228863ea42fe7ca4e9044b9b1b80e16c22ffd00150ae_prof);

        
        $__internal_6dec68ff8eb880ecd83b06dd2e046090f70231f3a91346ae0fa1b22d8448553e->leave($__internal_6dec68ff8eb880ecd83b06dd2e046090f70231f3a91346ae0fa1b22d8448553e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
