<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_f313131ae50d0e4ff6dad3a418af362e3db9cb99efb172570eb9d9ae5dee963e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ba707f49cac9df5b971cd8e407ca10c5356008859d0f6a9e30e6f1ee3d39547 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ba707f49cac9df5b971cd8e407ca10c5356008859d0f6a9e30e6f1ee3d39547->enter($__internal_9ba707f49cac9df5b971cd8e407ca10c5356008859d0f6a9e30e6f1ee3d39547_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_068b9fd1e20c3f128f7f4c67a286aa4fc3c986c818a85f77cf96d0e2e94ea2e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_068b9fd1e20c3f128f7f4c67a286aa4fc3c986c818a85f77cf96d0e2e94ea2e9->enter($__internal_068b9fd1e20c3f128f7f4c67a286aa4fc3c986c818a85f77cf96d0e2e94ea2e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ba707f49cac9df5b971cd8e407ca10c5356008859d0f6a9e30e6f1ee3d39547->leave($__internal_9ba707f49cac9df5b971cd8e407ca10c5356008859d0f6a9e30e6f1ee3d39547_prof);

        
        $__internal_068b9fd1e20c3f128f7f4c67a286aa4fc3c986c818a85f77cf96d0e2e94ea2e9->leave($__internal_068b9fd1e20c3f128f7f4c67a286aa4fc3c986c818a85f77cf96d0e2e94ea2e9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_ae3b749454b3ba34efe238d95db07c327d6d597dc45223b57a87265279f1cf50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae3b749454b3ba34efe238d95db07c327d6d597dc45223b57a87265279f1cf50->enter($__internal_ae3b749454b3ba34efe238d95db07c327d6d597dc45223b57a87265279f1cf50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_83bb29d2f193eaba9769584b96f75b05185c6adda065c8eee7a1cb060997dd2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83bb29d2f193eaba9769584b96f75b05185c6adda065c8eee7a1cb060997dd2c->enter($__internal_83bb29d2f193eaba9769584b96f75b05185c6adda065c8eee7a1cb060997dd2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_83bb29d2f193eaba9769584b96f75b05185c6adda065c8eee7a1cb060997dd2c->leave($__internal_83bb29d2f193eaba9769584b96f75b05185c6adda065c8eee7a1cb060997dd2c_prof);

        
        $__internal_ae3b749454b3ba34efe238d95db07c327d6d597dc45223b57a87265279f1cf50->leave($__internal_ae3b749454b3ba34efe238d95db07c327d6d597dc45223b57a87265279f1cf50_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_17300794d1e325afa373fa3d166dcbdb4bc7beb00e50d81aa5615e5ebf651895 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_17300794d1e325afa373fa3d166dcbdb4bc7beb00e50d81aa5615e5ebf651895->enter($__internal_17300794d1e325afa373fa3d166dcbdb4bc7beb00e50d81aa5615e5ebf651895_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_68568fca0224b9955c47b2f93627b91e054c57f065c06025ec256093b0bfc13d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68568fca0224b9955c47b2f93627b91e054c57f065c06025ec256093b0bfc13d->enter($__internal_68568fca0224b9955c47b2f93627b91e054c57f065c06025ec256093b0bfc13d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_68568fca0224b9955c47b2f93627b91e054c57f065c06025ec256093b0bfc13d->leave($__internal_68568fca0224b9955c47b2f93627b91e054c57f065c06025ec256093b0bfc13d_prof);

        
        $__internal_17300794d1e325afa373fa3d166dcbdb4bc7beb00e50d81aa5615e5ebf651895->leave($__internal_17300794d1e325afa373fa3d166dcbdb4bc7beb00e50d81aa5615e5ebf651895_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\wamp\\www\\workshopB3\\api\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
