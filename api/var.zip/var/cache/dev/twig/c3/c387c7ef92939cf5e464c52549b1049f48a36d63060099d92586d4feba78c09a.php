<?php

/* ::base.html.twig */
class __TwigTemplate_663eea4e437d11d65ce2026362a629afabc02efe2744c3ce36d7fed1acef5675 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e0ba7c035c88034621f86c77ddb84a869f24f34f9cca059e5484f89932d8e94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e0ba7c035c88034621f86c77ddb84a869f24f34f9cca059e5484f89932d8e94->enter($__internal_6e0ba7c035c88034621f86c77ddb84a869f24f34f9cca059e5484f89932d8e94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_9758d6e8833ab7e9e95ce37e38f59295288d6aa4bc33cd7c70d84bcb83fb553f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9758d6e8833ab7e9e95ce37e38f59295288d6aa4bc33cd7c70d84bcb83fb553f->enter($__internal_9758d6e8833ab7e9e95ce37e38f59295288d6aa4bc33cd7c70d84bcb83fb553f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_6e0ba7c035c88034621f86c77ddb84a869f24f34f9cca059e5484f89932d8e94->leave($__internal_6e0ba7c035c88034621f86c77ddb84a869f24f34f9cca059e5484f89932d8e94_prof);

        
        $__internal_9758d6e8833ab7e9e95ce37e38f59295288d6aa4bc33cd7c70d84bcb83fb553f->leave($__internal_9758d6e8833ab7e9e95ce37e38f59295288d6aa4bc33cd7c70d84bcb83fb553f_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_c2547c8659866961ee1d451f1b579095f8f4ad3fb715eda0ccf2cc2f230cc01f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c2547c8659866961ee1d451f1b579095f8f4ad3fb715eda0ccf2cc2f230cc01f->enter($__internal_c2547c8659866961ee1d451f1b579095f8f4ad3fb715eda0ccf2cc2f230cc01f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_495de9e43ab27d85f8350db139dce8692ee6b200fc732c351bfff1d3d7262925 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_495de9e43ab27d85f8350db139dce8692ee6b200fc732c351bfff1d3d7262925->enter($__internal_495de9e43ab27d85f8350db139dce8692ee6b200fc732c351bfff1d3d7262925_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_495de9e43ab27d85f8350db139dce8692ee6b200fc732c351bfff1d3d7262925->leave($__internal_495de9e43ab27d85f8350db139dce8692ee6b200fc732c351bfff1d3d7262925_prof);

        
        $__internal_c2547c8659866961ee1d451f1b579095f8f4ad3fb715eda0ccf2cc2f230cc01f->leave($__internal_c2547c8659866961ee1d451f1b579095f8f4ad3fb715eda0ccf2cc2f230cc01f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8d14651b4b8d0cac3a4be20c9628511cafaeccfb8b84008b190751a0069ad57b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d14651b4b8d0cac3a4be20c9628511cafaeccfb8b84008b190751a0069ad57b->enter($__internal_8d14651b4b8d0cac3a4be20c9628511cafaeccfb8b84008b190751a0069ad57b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a3a540a149628f9d079bef98cde1e961e2020c6da2228f2fbde0b3909fc0d673 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3a540a149628f9d079bef98cde1e961e2020c6da2228f2fbde0b3909fc0d673->enter($__internal_a3a540a149628f9d079bef98cde1e961e2020c6da2228f2fbde0b3909fc0d673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_a3a540a149628f9d079bef98cde1e961e2020c6da2228f2fbde0b3909fc0d673->leave($__internal_a3a540a149628f9d079bef98cde1e961e2020c6da2228f2fbde0b3909fc0d673_prof);

        
        $__internal_8d14651b4b8d0cac3a4be20c9628511cafaeccfb8b84008b190751a0069ad57b->leave($__internal_8d14651b4b8d0cac3a4be20c9628511cafaeccfb8b84008b190751a0069ad57b_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_4a7a9f53d96e9c31c243a83073f5a1902220f9231bbeef207335d5326dd99796 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a7a9f53d96e9c31c243a83073f5a1902220f9231bbeef207335d5326dd99796->enter($__internal_4a7a9f53d96e9c31c243a83073f5a1902220f9231bbeef207335d5326dd99796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b821488fa925d98f3d4a8f066683a89c5da6e0a776583567c143cb4c12e3c21a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b821488fa925d98f3d4a8f066683a89c5da6e0a776583567c143cb4c12e3c21a->enter($__internal_b821488fa925d98f3d4a8f066683a89c5da6e0a776583567c143cb4c12e3c21a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_b821488fa925d98f3d4a8f066683a89c5da6e0a776583567c143cb4c12e3c21a->leave($__internal_b821488fa925d98f3d4a8f066683a89c5da6e0a776583567c143cb4c12e3c21a_prof);

        
        $__internal_4a7a9f53d96e9c31c243a83073f5a1902220f9231bbeef207335d5326dd99796->leave($__internal_4a7a9f53d96e9c31c243a83073f5a1902220f9231bbeef207335d5326dd99796_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6a4e0bf065c8eaa63cd039de651db6bfa800db631563c12acf227a617ec31881 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a4e0bf065c8eaa63cd039de651db6bfa800db631563c12acf227a617ec31881->enter($__internal_6a4e0bf065c8eaa63cd039de651db6bfa800db631563c12acf227a617ec31881_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_5b179222a97d99b98a860fd4b3e3a3f7aee923eae4fe1617d83af80ba14f9d99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b179222a97d99b98a860fd4b3e3a3f7aee923eae4fe1617d83af80ba14f9d99->enter($__internal_5b179222a97d99b98a860fd4b3e3a3f7aee923eae4fe1617d83af80ba14f9d99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_5b179222a97d99b98a860fd4b3e3a3f7aee923eae4fe1617d83af80ba14f9d99->leave($__internal_5b179222a97d99b98a860fd4b3e3a3f7aee923eae4fe1617d83af80ba14f9d99_prof);

        
        $__internal_6a4e0bf065c8eaa63cd039de651db6bfa800db631563c12acf227a617ec31881->leave($__internal_6a4e0bf065c8eaa63cd039de651db6bfa800db631563c12acf227a617ec31881_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\wamp\\www\\workshopB3\\api\\app/Resources\\views/base.html.twig");
    }
}
